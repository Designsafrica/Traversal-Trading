<?php
include'../includes/connection.php';
?>
          <!-- Page Content -->
          <div class="col-lg-12">
            <?php
              $rn = $_POST['req_number'];
              $name = $_POST['requested_by'];
              $desc = $_POST['description'];
              $cat = $_POST['req_category'];
              $ph = $_POST['phone_number'];
              $am = $_POST['amount']; 
              $dor = $_POST['date_of_req'];
        
              switch($_GET['action']){
                case 'add':  
                for($i=0; $i < $qty; $i++){
                    $query = "INSERT INTO requesation
                              (REQ_ID, REQ_NUMBER, REQUESTED_BY, DESCRIPTION, REQ_CATEGORY, PHONE_NUMBER, AMOUNT, DATE_OF_REQ)
                              VALUES (Null,'{$rn}','{$name}','{$desc}',{$cat},{$ph},{$am},'{$dor}')";
                    mysqli_query($db,$query)or die ('Error in updating requesation in Database '.$query);
                    }
                break;
              }
            ?>
              <script type="text/javascript">window.location = "pos.php";</script>
          </div>

<?php
include'../includes/footer.php';
?>