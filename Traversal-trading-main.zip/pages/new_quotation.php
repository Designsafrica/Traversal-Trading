<?php
include'../includes/connection.php';
include'../includes/sidebar.php';

$sql_customer = "SELECT * FROM customer order by FULL_NAME asc";
$result_customer = mysqli_query($db, $sql_customer) or die ("Bad SQL: $sql");

$opt_customer = "<select class='form-control' name='customer_name'>
        <option disabled selected>Select Customer</option>";
  while ($row_customer = mysqli_fetch_assoc($result_customer)) {
    $opt_customer .= "<option value='".$row_customer['FULL_NAME']."'>".$row_customer['FULL_NAME']."</option>";

  }

$opt_customer .= "</select>";

$sql_product = "SELECT * FROM product order by PRODUCT_ID asc";
$result_product = mysqli_query($db, $sql_product) or die ("Bad SQL: $sql");

$opt_product = "<select class='form-control' name='product'>
        <option disabled selected>Select Product</option>";
  while ($opt_product = mysqli_fetch_assoc($result_customer)) {
    $opt_product .= "<option value='".$row_product['NAME']."'>".$opt_product['NAME']."</option>";

  }

$opt_product .= "</select>";
$s = uniqid((int)(date('Ymd') . rand(1, 1000)));

  $query = 'SELECT ID, t.TYPE
            FROM users u
            JOIN type t ON t.TYPE_ID=u.TYPE_ID WHERE ID = '.$_SESSION['MEMBER_ID'].'';
  $result = mysqli_query($db, $query) or die (mysqli_error($db));
  
  while ($row = mysqli_fetch_assoc($result)) {
            $Aa = $row['TYPE'];
                   
  if ($Aa=='User'){
?>
  <script type="text/javascript">
    //then it will be redirected
    alert("Restricted Page! You will be redirected to POS");
    window.location = "pos.php";
  </script>
<?php
  }           
}
            ?>
            
            <div class="card shadow mb-4">
              <div class="card-header py-3">
             
              <h4 class="m-2 font-weight-bold text-primary">
                Quotation&nbsp;
              </h4>
              </div>
              <div class="card-body">
                <div class="row">
                  <div class="form-group col-md-6">
                    <label>Quotation Number</label>
                    <input class="form-control col-md-6" placeholder="Quotation No." name="quote_number" value="<?php echo $s;?>" required readonly>
                  </div>

                  <div class="form-group col-md-6">
                    <label>Customer Name</label>
                    <?php
                      echo $opt_customer;
                    ?>

                  </div>
                </div>

                <div class="row">
                  <div class="col-md-12" style="overflow-x:auto;">
                <h4 style="margin-top: 20px; border-bottom: solid; border-bottom-color: blue; border-top: solid; border-top-right-radius: 40px; border-bottom-left-radius: 40px; padding-left: 30px; ">
                  <b>Quotation Details</b>
                </h4>
                <table class="table table-border" id="myOrder">
                  <thead>
                      <tr>
                          <th></th>
                          <th>Code</th>
                          <th>Name</th>
                          <th>Stock</th>
                          <th>Price</th>
                          <th>Quantity</th>
                          <th>Unit</th>
                          <th>Total</th>
                          <th>
                            <button type="button" id="addOrder" name="addOrder" class="btn btn-info btn-sm btn_addOrder" required><span>
                              <i class="fa fa-plus"></i>
                            </span></button>
                          </th>
                      </tr>

                  </thead>
                  <tbody>

                  </tbody>
                </table>
              </div>
                </div>
              </div>
              <div class="card-footer">
                 <div class="row">
                  <div class="col-md-6">
                    <input type="submit" name="save_order" value="Save Quotation" class="form-control btn btn-success">
                  </div>
                  <div class="col-md-6">
                    <a href="order.php" class="form-control btn btn-warning">Back</a>
                  </div>
                 </div>
              </div>
            </div>
<script>
  if(document.getElementById('addOrder').clicked == true)
  {
     alert("button was clicked");
     exit();
  }
  $(document).ready(function(){
      $(document).on('click','.btn_addOrder', function(){
        var html='';
        html+='<tr>';
        html+='<td><input type="hidden" class="form-control productcode" name="productcode[]" readonly></td>';
        html+='<td><?php echo $opt_product; ?></td>';
        html+='<td><input type="text" class="form-control productname" style="width:200px;" name="productname[]" readonly></td>';
        html+='<td><input type="text" class="form-control productstock" style="width:50px;" name="productstock[]" readonly></td>';
        html+='<td><input type="text" class="form-control productprice" style="width:100px;" name="productprice[]" readonly></td>';
        html+='<td><input type="number" min="1" max="50" class="form-control quantity_product" style="width:100px;" name="quantity[]" required></td>';
        html+='<td><input type="text" class="form-control productsatuan" style="width:100px;" name="productsatuan[]" readonly></td>';
        html+='<td><input type="text" class="form-control producttotal" style="width:150px;" name="producttotal[]" readonly></td>';
        html+='<td><button type="button" name="remove" class="btn btn-danger btn-sm btn-remove"><i class="fa fa-remove"></i></button></td>'

        $('#myOrder').append(html);

        $('.productid').on('change', function(e){
          var productid = this.value;
          var tr=$(this).parent().parent();
          $.ajax({
            url:"getproduct.php",
            method:"get",
            data:{id:productid},
            success:function(data){
              //console.log(data);
              tr.find(".productcode").val(data["product_code"]);
              tr.find(".productname").val(data["product_name"]);
              tr.find(".productstock").val(data["stock"]);
              tr.find(".productsatuan").val(data["product_satuan"]);
              tr.find(".productprice").val(data["sell_price"]);
              tr.find(".quantity_product").val(0);
              tr.find(".producttotal").val(tr.find(".quantity_product").val() * tr.find(".productprice").val());
              calculate(0,0);
            }
          })
        })

      })


</script>
<?php
include'../includes/footer.php';
?>

