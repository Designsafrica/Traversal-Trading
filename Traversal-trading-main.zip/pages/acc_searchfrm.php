<?php
include'../includes/connection.php';
include'../includes/sidebar.php';

  $query1 = 'SELECT * FROM tbl_accounts_details WHERE account_id ='.$_GET['id'];
            $result1 = mysqli_query($db, $query1) or die(mysqli_error($db));
              while($row1 = mysqli_fetch_array($result1))
              {   
                $account_holder= $row1['account_holder'];
                $account_type= $row1['account_type'];
                $amount_paid= $row1['amount_paid'];
                $date_paid=$row1['date_paid'];
               
              }
              $id = $_GET['id'];

  $query2 = 'SELECT * FROM tbl_accounts WHERE id='.$_GET['id'];
  $result2 = mysqli_query($db, $query2) or die (mysqli_error($db));

      while ($row2 = mysqli_fetch_assoc($result2)) {
        $account_balance= $row2['account_balance'];
        
      }

  $query = 'SELECT ID, t.TYPE
            FROM users u
            JOIN type t ON t.TYPE_ID=u.TYPE_ID WHERE ID = '.$_SESSION['MEMBER_ID'].'';
  $result = mysqli_query($db, $query) or die (mysqli_error($db));
  
  while ($row = mysqli_fetch_assoc($result)) {
            $Aa = $row['TYPE'];
                   
  if ($Aa=='User'){
?>
  <script type="text/javascript">
    //then it will be redirected
    alert("Restricted Page! You will be redirected to POS");
    window.location = "pos.php";
  </script>
<?php
  }           
}
            ?>
          <center><div class="card shadow mb-4 col-xs-12 col-md-8 border-bottom-primary">
            <div class="card-header py-3">
              <h4 class="m-2 font-weight-bold text-primary">Account Detail - <?php echo $account_holder;?></h4>
            </div>
            <a href="account_statements.php?action=add" type="button" class="btn btn-primary bg-gradient-primary btn-block"> <i class="fas fa-flip-horizontal fa-fw fa-share"></i> Back</a>
            <div class="card-body">
          <?php 
            $query = 'SELECT * FROM tbl_accounts_details WHERE account_id ='.$_GET['id'];
            $result = mysqli_query($db, $query) or die(mysqli_error($db));
              while($row = mysqli_fetch_array($result))
              {   
                $account_holder= $row['account_holder'];
                $account_type= $row['account_type'];
                $amount_paid= $row['amount_paid'];
                $date_paid=$row['date_paid'];
               
              }
              $id = $_GET['id'];
          ?>

                  <div class="form-group row text-left">
                      <div class="col-sm-3 text-primary">
                        <h5>
                          Account Holder<br>
                        </h5>
                      </div>
                      <div class="col-sm-9">
                        <h5>
                          : <?php echo $account_type; ?><br>
                        </h5>
                      </div>
                    </div>

                    <div class="form-group row text-left">
                      <div class="col-sm-3 text-primary">
                        <h5>
                          Account Balance<br>
                        </h5>
                      </div>
                      <div class="col-sm-9">
                        <h5>
                          : $<?php echo $account_balance; ?><br>
                        </h5>
                      </div>
                    </div>
                    
                      
                    </div>
                  
                  
                  
                </div>
          </div></center>

          <div class="card shadow mb-4 col-xs-12 col-md-15 border-bottom-primary">
            <div class="card-header py-3">
              <h4 class="m-2 font-weight-bold text-primary">Details</h4>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0"> 
               <thead>
                   <tr>
                     <th></th>
                     <th>Amount Paid</th>
                     <th>Date Paid</th>
                     
                   </tr>
               </thead>
          <tbody>

<?php 
    $no = 1;
      $query1 = 'SELECT * FROM tbl_accounts_details WHERE account_id ='.$_GET['id'];
            $result1 = mysqli_query($db, $query1) or die(mysqli_error($db));
                  
    // $query = 'SELECT PRODUCT_ID, PRODUCT_CODE, NAME, COUNT("QTY_STOCK") AS QTY_STOCK, COUNT("ON_HAND") AS ON_HAND, CNAME, COMPANY_NAME, p.SUPPLIER_ID, DATE_STOCK_IN FROM product p join category c on p.CATEGORY_ID=c.CATEGORY_ID JOIN supplier s ON p.SUPPLIER_ID=s.SUPPLIER_ID where PRODUCT_CODE ='.$zzz.' GROUP BY `SUPPLIER_ID`, `DATE_STOCK_IN`';
        // $result = mysqli_query($db, $query) or die (mysqli_error($db));
            while($row1 = mysqli_fetch_array($result1))
              {   
               
                echo '<tr>';
                echo '<td>'. $no++.'</td>';
                echo '<td>'. $row1['amount_paid'].'</td>';
                echo '<td>'. $row1['date_paid'].'</td>';
                
                echo '</tr> ';
               
              }
            
?> 
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                  </div>
                </div>


<?php
include'../includes/footer.php';
?>