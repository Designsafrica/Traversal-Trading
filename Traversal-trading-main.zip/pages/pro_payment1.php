<?php
include('../includes/connection.php');

	$id = $_POST['account_id'];
	$account_holder = $_POST['account_holder'];
	$account_type = $_POST['account_type'];
	$account_bal = $_POST['account_balance'];
	$amount_paid = $_POST['price'];
	$today_date = $_POST['today_date'];

  $query1 = "SELECT * FROM tbl_accounts WHERE id ='$id'";
            $result1 = mysqli_query($db, $query1) or die(mysqli_error($db));
              while($row1 = mysqli_fetch_array($result1))
              {   
                $account_holder= $row1['account_holder'];
                $phone_number= $row1['phone_number'];
                $account_type= $row1['account_type'];
                $account_balance= $row1['account_balance'];
                
              }


            $balance = $account_balance - $amount_paid;
            

            $query = "UPDATE tbl_accounts SET account_balance = '$balance'";
		
	 			// $query = 'UPDATE product set NAME="'.$pname.'",
					// DESCRIPTION="'.$desc.'", PRICE="'.$pr.'", CATEGORY_ID ="'.$cat.'" WHERE
					// PRODUCT_CODE ="'.$pc.'"';
				// $query = 'UPDATE tbl_accounts set '
					$result = mysqli_query($db, $query) or die(mysqli_error($db));
	// $insert = "INSERT INTO tbl_accounts_details('account_id', 'account_holder', 'account_type', 'amount_paid', 'date_paid') VALUES ('$id','$account_holder','$account_type','$amount_paid','$today_date')";
	// mysqli_query($db,$insert)or die (mysqli_error($db));

	$query111 = "INSERT INTO `tbl_accounts_details`
                               (`account_id`, `account_holder`, `account_type`, `amount_paid`, `date_paid`)
                               VALUES ('{$id}','{$account_holder}','{$account_type}','{$amount_paid}','{$today_date}')";
                    mysqli_query($db,$query111)or die (mysqli_error($db));

							
?>	
	<script type="text/javascript">
			// alert("You've Updated The Account Successfully Successfully.");
			alert("You've Updated The Account Successfully Successfully.")
			window.location = "account_statements.php";
		</script>