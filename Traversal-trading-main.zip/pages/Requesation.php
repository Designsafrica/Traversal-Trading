<?php
include'../includes/connection.php';
include'../includes/sidebar.php';
  $query = 'SELECT ID, t.TYPE
            FROM users u
            JOIN type t ON t.TYPE_ID=u.TYPE_ID WHERE ID = '.$_SESSION['MEMBER_ID'].'';
  $result = mysqli_query($db, $query) or die (mysqli_error($db));
  
  while ($row = mysqli_fetch_assoc($result)) {
            $Aa = $row['TYPE'];
                   
  if ($Aa=='User'){
?>
  <script type="text/javascript">
    //then it will be redirected
    alert("Restricted Page! You will be redirected to POS");
    window.location = "pos.php";
  </script>
<?php
  }           
}
            ?>
            
            <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h4 class="m-2 font-weight-bold text-primary">Requesations</h4>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0"> 
               <thead>
                   <tr>
                     <th>Requesation Number</th>
                     <th>Requested By</th>
                     <th>Description</th>
                     <th>Recieved As</th>
                     <th>Phone Number</th>
                     <th>Amount</th>
                     <th>Date of Requesation</th>
                   </tr>
               </thead>
          <tbody>

<?php                  
    $query = 'SELECT REQ_ID, REQ_NUMBER, REQUESTED_BY, DESCRIPTION, PHONE_NUMBER, AMOUNT, DATE_OF_REQ FROM requesation p join req_category c on p.REQ_ID where REQ_NUMBER = REQ_NUMBER';
        $result = mysqli_query($db, $query) or die (mysqli_error($db));
      
            while ($row = mysqli_fetch_assoc($result)) {
                                 
                echo '<tr>';
                echo '<td>'. $row['REQ_NUMBER'].'</td>';
                echo '<td>'. $row['REQUESTED_BY'].'</td>';
                echo '<td>'. $row['DESCRIPTION'].'</td>';
                echo '<td>'. $row['PHONE_NUMBER'].'</td>';
                echo '<td>'. $row['AMOUNT'].'</td>';
                echo '<td>'. $row['DATE_OF_REQ'].'</td>';
                      echo '<td align="right">
                              <a type="button" class="btn btn-primary bg-gradient-primary" href="req_searchfrm.php?action=edit & id='.$row['PRODUCT_CODE'] . '"><i class="fas fa-fw fa-th-list"></i> View</a>
                          </div> </td>';
                echo '</tr> ';
                        }
?> 
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                  </div>

<?php
include'../includes/footer.php';
?>
